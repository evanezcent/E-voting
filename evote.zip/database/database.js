module.exports = {
    MongoURI: 'mongodb+srv://root:root123@evotte-hro6a.mongodb.net/test?retryWrites=true&w=majority'
}